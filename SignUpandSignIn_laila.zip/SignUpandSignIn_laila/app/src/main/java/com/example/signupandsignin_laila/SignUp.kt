package com.example.signupandsignin_laila

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        supportActionBar?.hide()

        var EditText_Name = findViewById<EditText>(R.id.EditText_Name)
        var EditText_Phone = findViewById<EditText>(R.id.EditText_Phone)
        var EditText_Location = findViewById<EditText>(R.id.EditText_Location)
        var EditText_Password = findViewById<EditText>(R.id.EditText_Password)
        var Button_Submit = findViewById<Button>(R.id.Button_Submit)
        var Button_home = findViewById<Button>(R.id.Button_home)

        Button_Submit.setOnClickListener {

            var helper = DBHelper(applicationContext)
            var name = EditText_Name.text.toString()
            var phone = EditText_Phone.text.toString()
            var location = EditText_Location.text.toString()
            var password = EditText_Password.text.toString()

            if(name.isNotEmpty() && phone.isNotEmpty() && location.isNotEmpty() && password.isNotEmpty() ) {
                helper.savedata(User(name, password, phone, location))

                Toast.makeText(this, "User added", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, Details::class.java)
                intent.putExtra("name", name)
                intent.putExtra("phone", phone)
                intent.putExtra("location", location)
                intent.putExtra("password", password)
                startActivity(intent)
            }
            else
            {
                Toast.makeText(this, "Please write all Details!!", Toast.LENGTH_LONG)
                    .show()
            }
        }

        Button_home.setOnClickListener { startActivity(Intent(this,MainActivity::class.java)) }
    }
}