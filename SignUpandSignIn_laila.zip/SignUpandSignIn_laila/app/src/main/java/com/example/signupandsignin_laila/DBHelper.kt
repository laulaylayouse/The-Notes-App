package com.example.signupandsignin_laila

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (context: Context) : SQLiteOpenHelper(context, "User_details.db", null, 1) {

    private var sqLiteDatabase: SQLiteDatabase = writableDatabase

    override fun onCreate(db: SQLiteDatabase?) {
        if(db != null)
        {
            db?.execSQL("create table users (Name text, Password text,Phone text,Location text)")
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion != newVersion && db != null) {
            db.execSQL("DROP TABLE IF EXISTS users")
            onCreate(db)
        }
    }

    fun savedata(s1: User): Long {

        val Content_Values = ContentValues()
        Content_Values.put("Name", s1.name)
        Content_Values.put("Password", s1.password)
        Content_Values.put("Phone", s1.phone)
        Content_Values.put("Location", s1.location)

        return sqLiteDatabase.insert("users", null, Content_Values)
    }

    @SuppressLint("Range")
    fun viewdata(): ArrayList<User>{

        val noteList: ArrayList<User> = ArrayList()
        val selectQuery = "SELECT * FROM users"
        var cursor: Cursor? = null

        try {

            cursor = sqLiteDatabase.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            sqLiteDatabase.execSQL(selectQuery)
        }

        var name: String
        var phone: String
        var location: String
        var password: String

        if (cursor != null) {
            if (cursor!!.moveToFirst()) {
                do {
                    name = cursor.getString(cursor.getColumnIndex("Name"))
                    phone = cursor.getString(cursor.getColumnIndex("Phone"))
                    location = cursor.getString(cursor.getColumnIndex("Location"))
                    password = cursor.getString(cursor.getColumnIndex("Password"))

                    val note = User(name,phone,location,password)
                    noteList.add(note)
                } while (cursor.moveToNext())
            }
        }

        return noteList
    }

    @SuppressLint("Range")
    fun checkUser(name: String, pass: String ): String {

        var cursor : Cursor = sqLiteDatabase.query("users" , null , "Name=?" , arrayOf(name) , null , null , null)
        cursor.moveToFirst()

        var phone: String
        var location: String
        var password: String

        phone = cursor.getString(cursor.getColumnIndex("Phone"))
        location = cursor.getString(cursor.getColumnIndex("Location"))
        password = cursor.getString(cursor.getColumnIndex("Password"))

        if (pass == password){
            return " Name: $name\n Password: $password\n Phone Number: $phone\n Location: $location\n"
        }else {
            return ""
        }

    }

}