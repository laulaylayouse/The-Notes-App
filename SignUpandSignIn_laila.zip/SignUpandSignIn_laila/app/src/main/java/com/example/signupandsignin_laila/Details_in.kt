package com.example.signupandsignin_laila

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Details_in : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details_in)
        supportActionBar?.hide()

        var TextView_Name = findViewById<TextView>(R.id.TextView_Name)
        var Button_SignOut = findViewById<Button>(R.id.Button_SignOut)
        var helper = DBHelper(applicationContext)
        val intent = intent

        try {
            val name1 = intent.getStringExtra("name_in").toString()
            val pass = intent.getStringExtra("password_in").toString()
            var s = helper.checkUser(name1, pass)
            TextView_Name.setText(s)
        }catch (e: Exception) {
            Toast.makeText(this, "Please write all Details correctly!!", Toast.LENGTH_LONG)
            startActivity(Intent(this,MainActivity::class.java))
        }
        if (TextView_Name.text == "TextView")
        {
            Toast.makeText(this, "Please write all Details correctly!!", Toast.LENGTH_LONG)
            startActivity(Intent(this,SignIn::class.java))
        }

        Button_SignOut.setOnClickListener { startActivity(Intent(this,MainActivity::class.java)) }
    }

}