package com.example.signupandsignin_laila


data class User(val name:String,val password:String, val phone:String,val location: String)