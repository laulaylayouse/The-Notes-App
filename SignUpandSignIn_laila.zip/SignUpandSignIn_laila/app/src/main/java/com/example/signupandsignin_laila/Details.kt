package com.example.signupandsignin_laila

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Details : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        supportActionBar?.hide()

        var TextView_Name = findViewById<TextView>(R.id.TextView_Name)
        var TextView_password = findViewById<TextView>(R.id.TextView_password)
        var TextView_Location = findViewById<TextView>(R.id.TextView_Location)
        var TextView_Phone = findViewById<TextView>(R.id.TextView_Phone)
        var Button_SignOut = findViewById<Button>(R.id.Button_SignOut)

        val intent = intent

            val name = intent.getStringExtra("name").toString()
            val phone = intent.getStringExtra("phone")
            val location = intent.getStringExtra("location")
            val password = intent.getStringExtra("password")
            TextView_Name.setText(name)
            TextView_Phone.setText(phone)
            TextView_Location.setText(location)
            TextView_password.setText(password)

        Button_SignOut.setOnClickListener { startActivity(Intent(this,MainActivity::class.java)) }
    }

}