package com.example.notesapp_laila

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView
    lateinit var EditText_add_Name: EditText
    lateinit var Button_Save: Button

    var s1 =""
    var Note_List = arrayListOf<Notes>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Note_List = Notes_List()

        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        Button_Save = findViewById(R.id.Button_Save)
        Recycler_View = findViewById(R.id.Recycler_View)
        Recycler_View.adapter = Adapter(this, this, Note_List)
        Recycler_View.layoutManager = LinearLayoutManager(this)
        Recycler_View.adapter!!.notifyDataSetChanged()

        Button_Save.setOnClickListener {
            s1 = EditText_add_Name.text.toString()

            if(s1.isNotEmpty()) {
                var helper = DBHelper(applicationContext)
                var add = helper.savedata(Notes(s1))

                Note_List.add(Notes(s1))
                Recycler_View.adapter!!.notifyDataSetChanged()

                EditText_add_Name.text.clear()
                Toast.makeText(this, "The Message added successfully $add", Toast.LENGTH_LONG)
                    .show()
            }
            else{

                Toast.makeText(this, "Please write The Message!!", Toast.LENGTH_LONG)
                    .show()

            }
        }

    }

    fun Notes_List(): ArrayList<Notes>{
        var helper = DBHelper(applicationContext)
        return helper.viewdata()
    }

    fun Update_List() {
        var helper = DBHelper(applicationContext)
        Note_List.addAll(helper.viewdata())
        Recycler_View.adapter!!.notifyDataSetChanged()

    }
}