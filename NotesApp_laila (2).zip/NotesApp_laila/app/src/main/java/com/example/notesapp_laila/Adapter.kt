package com.example.notesapp_laila

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_update_delete.view.*
import kotlinx.android.synthetic.main.item_row.view.*

class Adapter (val mainActivity: MainActivity, val context: Context, private val messages: List<Notes>):
    RecyclerView.Adapter<Adapter.ItemViewHolder>(){
    class ItemViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        var message = messages[position]

        holder.itemView.apply {

            TextView_Name.text = message.noteText
            ImageView_more.setOnClickListener {

                val dbHelper = DBHelper(context)
                val builder = AlertDialog.Builder(context)
                val dialogView =
                    LayoutInflater.from(context).inflate(R.layout.activity_update_delete, null)
                builder.setView(dialogView)
                val alertDialog: AlertDialog = builder.create()
                dialogView.EditText_add_Name_u.setText(message.noteText)
                dialogView.Button_Update.setOnClickListener {
                    val updatedNote = dialogView.EditText_add_Name_u.text.toString()
                    if (updatedNote.isNotEmpty()) {
                        val rowNum = dbHelper.updatedata(Notes(updatedNote), message.noteText)
                        Toast.makeText(context, "Updated successfully. ", Toast.LENGTH_SHORT).show()
                        alertDialog.dismiss()
                        mainActivity.Update_List()

                    } else {
                        Toast.makeText(context, "Please write The Message!!", Toast.LENGTH_SHORT)
                            .show()
                    }

                }
                dialogView.Button_Delete.setOnClickListener {
                    val deleteBuilder = AlertDialog.Builder(context)
                    deleteBuilder.setTitle("Delete note")
                    deleteBuilder.setMessage("Are you sure you want to delete this Message?")
                    deleteBuilder.setIcon(android.R.drawable.ic_dialog_alert)

                    deleteBuilder.setPositiveButton("Delete") { dialogInterface, which ->
                        dbHelper.deletedata(message.noteText)
                        mainActivity.Update_List()
                        alertDialog.dismiss()
                    }
                    deleteBuilder.setNeutralButton("Cancel") { dialogInterface, which ->
                        dialogInterface.dismiss()
                    }
                    deleteBuilder.setCancelable(true)
                    deleteBuilder.show()
                }
                dialogView.Button_Back.setOnClickListener {
                    alertDialog.dismiss()

                }
                alertDialog.getWindow()?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                alertDialog.setCancelable(true)
                alertDialog.show()
            }

        }
    }

    override fun getItemCount()= messages.size
}

