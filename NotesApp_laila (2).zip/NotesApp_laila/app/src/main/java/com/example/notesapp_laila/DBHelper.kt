package com.example.notesapp_laila

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (context: Context) : SQLiteOpenHelper(context, "notes_details.db", null, 1) {

    private var sqLiteDatabase: SQLiteDatabase = writableDatabase

    override fun onCreate(db: SQLiteDatabase?) {
        if(db != null)
        {
            db?.execSQL("create table notes (Message text )")
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun savedata(s1: Notes): Long {

        val Content_Values = ContentValues()
        Content_Values.put("Message", s1.noteText)

        return sqLiteDatabase.insert("notes", null, Content_Values)
    }

    @SuppressLint("Range")
    fun viewdata(): ArrayList<Notes>{

        val noteList: ArrayList<Notes> = ArrayList()
        val selectQuery = "SELECT * FROM notes"
        var cursor: Cursor? = null

        try {

            cursor = sqLiteDatabase.rawQuery(selectQuery, null)
        } catch (e: SQLiteException) {
            sqLiteDatabase.execSQL(selectQuery)
        }

        var noteText: String

        if (cursor != null) {
            if (cursor!!.moveToFirst()) {
                do {
                    noteText = cursor.getString(cursor.getColumnIndex("Message"))

                    val note = Notes(noteText = noteText)
                    noteList.add(note)
                } while (cursor.moveToNext())
            }
        }

        return noteList
    }

    fun updatedata(noteOBJ:Notes,oldNote: String): Int {
        val cv = ContentValues()
        cv.put("Message", noteOBJ.noteText)

        var rowNum = sqLiteDatabase.update("notes", cv,"Message = ?", arrayOf(oldNote))
        return rowNum

    }
    fun deletedata(note: String){
        sqLiteDatabase.delete("notes","Message=?", arrayOf(note))
    }
}